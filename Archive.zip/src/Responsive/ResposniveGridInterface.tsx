interface ResponsiveGridProps {
    children: React.ReactNode;
}
export type { ResponsiveGridProps };
