interface GamesProps {
    gameTabMenuActive: number | null;
    setGameTabMenuActive: (id: number) => void;
}

export type { GamesProps };
