interface GamesTabProps {
    gameTabMenuActive: number | null;
    setGameTabMenuActive: (id: number) => void;
}

export type { GamesTabProps };
