interface TabMenuProps {
    tabMenuActive: number | null;
    setTabMenuActive: (id: number) => void;
}

export type { TabMenuProps };
