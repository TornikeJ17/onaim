interface SidebarProps {
    isActive: number | null;
    setIsActive: (id: number) => void;
}
export type { SidebarProps };
