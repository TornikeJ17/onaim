interface ButtonProps {
    width?: string;
    height?: string;
    backgroundColor?: string;
    color?: string;
    title?: string;
    hover?: string;
}

export type { ButtonProps };
